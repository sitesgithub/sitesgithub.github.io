if (process.platform === "win32") {
  var rl = require("readline").createInterface({
    input: process.stdin,
    output: process.stdout
  });

  rl.on("SIGINT", function () {
    process.emit("SIGINT");
  });
}

process.on("SIGINT", function () {
  console.log('\nExited forcefully.')
  process.exit();
});

const fs = require('fs');
const request = require('request');
const colors = require('colors');
const prompt = require('prompt');
const readline = require('readline');
const agent = require('socks5-http-client/lib/Agent')
const url = require('url')
var opts = url.parse('http://sitesgithub.github.io/test.json');
const SocksProxyAgent = require('socks-proxy-agent')
fs.writeFile('workingproxies.txt', '', function(){})
let file = ""
let proxy = ""
console.log(colors.magenta('Input the path of the proxy file! ex. proxies.txt\n'))
prompt.start()
prompt.get(['file'], function (err, result) {
    if (err) { throw err; }
file = result.file
console.log('\n[1] HTTP Proxies\n[2] Socks4 Proxies\n[3] Socks5 Proxies')
wait()
});

function wait() {
  prompt.start()
prompt.get(['type'], function (err, result) {
    if (err) { throw err; }
    proxy = result.type
    read()
});
}

function read() {
const readInterface = readline.createInterface({
    input: fs.createReadStream(file),
    output: "",
    console: false
});
readInterface.on('line', function(line) {
  if (proxy == "1") {
  request.get({
    uri: 'http://sitesgithub.github.io/test.json',
    proxy: 'http://'+line,
    forever: true
}, function (err, resp, body) {
    if (err) {
      
        return console.log(colors.red(`${line} | Dead`));
      
    }
    try {
      
            body = JSON.parse(body);
            if(body.status == "200"){
                console.log(colors.green(`${line} | Alive`));
                fs.appendFileSync("workingproxies.txt", line+'\n', "UTF-8",{'flags': 'a+'});
            }
            else {
                console.log(colors.red(`a`));
            }
        }
        catch (error) {
      
        return console.log(colors.red(`${line} | Dead`));
      
        }
});
} else if (proxy == "2") {
let aGent = new SocksProxyAgent('socks4://'+line);
opts.agent = aGent
      request.get({
    uri: 'http://sitesgithub.github.io/test.json',
    agent: aGent,
    forever: true
}, function (err, resp, body) {
    if (err) {
      
        return console.log(colors.red(`${line} | Dead`));
      
    }
    try {
      
            body = JSON.parse(body);
            if(body.status == "200"){
                console.log(colors.green(`${line} | Alive`));
                fs.appendFileSync("workingproxies.txt", line+'\n', "UTF-8",{'flags': 'a+'});
            }
            else {
                console.log(colors.red(`a`));
            }
        }
        catch (error) {
      
        return console.log(colors.red(`${line} | Dead`));
      
        }
});
} else if (proxy == "3") {
    request.get({
    uri: 'http://sitesgithub.github.io/test.json',
    agentClass: agent,
    agentOptions: {
		  socksHost: line.split(':')[0],
		  socksPort: line.split(':')[1]
	  }
}, function (err, resp, body) {
    if (err) {
      
        return console.log(colors.red(`${line} | Dead`));
      
    }
    try {
      
            body = JSON.parse(body);
            if(body.status == "200"){
                console.log(colors.green(`${line} | Alive`));
                fs.appendFileSync("workingproxies.txt", line+'\n', "UTF-8",{'flags': 'a+'});
            }
            else {
                console.log(colors.red(`a`));
            }
        }
        catch (error) {
      
        return console.log(colors.red(`${line} | Dead`));
      
        }
});
}
});
};